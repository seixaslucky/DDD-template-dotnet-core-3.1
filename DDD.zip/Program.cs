using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Events;
using System;

namespace $safeprojectname$
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Log.Logger = new LoggerConfiguration()
                  .MinimumLevel.Debug()
                  .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                  .Enrich.FromLogContext()
                  .WriteTo.Console(outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] ({SourceContext}.{Method}) {Message} (at {Caller}){NewLine}{Exception}")
                  .WriteTo.File("logs\\Log.txt", rollingInterval: RollingInterval.Day
                  , outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] ({SourceContext}.{Method}) {Message} (at {Caller}){NewLine}{Exception}"
                  , restrictedToMinimumLevel: LogEventLevel.Error)
                  .CreateLogger();

            try
            {
                Log.Information("Stating Application...");
                CreateHostBuilder(args).Build().Run();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Application start-up failed");
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseSerilog() // Replace the default logging provider
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
