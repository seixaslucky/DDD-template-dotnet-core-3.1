﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Domain.Responses
{
    public interface IResponse
    {
        public bool Sucesso { get; set; }
        public string Mensagem { get; set; }
    }
}
