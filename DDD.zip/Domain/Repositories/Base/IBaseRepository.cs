﻿using System.Collections.Generic;
using System.Threading.Tasks;
using $safeprojectname$.Domain.Entities.Base;

namespace $safeprojectname$.Domain.Repositories.Base
{
    public interface IBaseRepository<T> where T : BaseEntity
    {
        Task<T> InsertAsync(T obj);
        Task<T> UpdateAsync(T obj);
        Task<bool> RemoveAsync(T obj);
        Task<bool> ExistAsync(string id);
        Task<T> SelectAsync(string id);
        Task<IEnumerable<T>> SelectAsync();
    }
}
