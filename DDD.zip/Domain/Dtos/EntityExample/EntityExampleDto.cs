﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Domain.Dtos.EntityExample
{
    public class EntityExampleDto
    {
        [Required]
        public string Id { get; set; }
        [Required]
        public string Nome { get; set; }
        public string Desprition { get; set; }
    }
}
