﻿

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using $safeprojectname$.Domain.Entities.Base;
using $safeprojectname$.Domain.Repositories.Base;
using $safeprojectname$.Infra.Context;

namespace $safeprojectname$.Infra.Repositories.Base
{
    public class BaseRepository<T> : IBaseRepository<T> where T : BaseEntity
    {
        protected readonly MyContext _context;
        private DbSet<T> _dataset;

        public BaseRepository(MyContext context)
        {
            _context = context;
            _dataset = _context.Set<T>();
        }

        public async Task<T> InsertAsync(T obj)
        {
            obj.CreatedAt = DateTime.UtcNow;

            _dataset.Add(obj);

            await _context.SaveChangesAsync();
            _context.Dispose();

            return obj;
        }

        public async Task<bool> RemoveAsync(T obj)
        {


            _dataset.Remove(obj);

            await _context.SaveChangesAsync();


            return true;
        }

        public async Task<T> SelectAsync(string id)
        {
            return await _dataset.FindAsync(id);
        }

        public async Task<IEnumerable<T>> SelectAsync()
        {
            return await _dataset.ToListAsync();
        }

        public async Task<T> UpdateAsync(T obj)
        {
            var result = await _dataset.SingleOrDefaultAsync(t => t.Id == obj.Id);

            if (result == null)
                return null;

            obj.CreatedAt = result.CreatedAt;

            _context.Entry(result).CurrentValues.SetValues(obj);

            await _context.SaveChangesAsync();
            _context.Dispose();

            return obj;
        }

        public async Task<bool> ExistAsync(string id)
        {
            return await _dataset.AnyAsync(t => t.Id == id);
        }
    }
}
