﻿

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using $safeprojectname$.Domain.Entities.Base;
using $safeprojectname$.Domain.Repositories.Base;
using $safeprojectname$.Infra.Context;

namespace $safeprojectname$.Infra.Repositories.Base
{
    public class BaseRepository<T> : IBaseRepository<T> where T : BaseEntity
    {
        protected readonly MyContext _context;
        private DbSet<T> _dataset;

        public BaseRepository(MyContext context)
        {
            _context = context;
            _dataset = _context.Set<T>();
        }

        public async Task<T> InsertAsync(T obj)
        {
            try
            {
                obj.CreatedAt = DateTime.UtcNow;

                _dataset.Add(obj);

                await _context.SaveChangesAsync();

                return obj;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IList<T>> InsertAsync(IList<T> obj)
        {
            try
            {
                for (int i = 0; i < obj.Count; i++)
                {
                    obj[i].CreatedAt = DateTime.UtcNow;
                }
                _dataset.AddRange(obj);

                await _context.SaveChangesAsync();

                return obj;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> RemoveAsync(T obj)
        {
            try
            {
                _dataset.Remove(obj);

                await _context.SaveChangesAsync();

                return true;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> RemoveAsync(IList<T> obj)
        {
            try
            {
                _dataset.RemoveRange(obj);

                await _context.SaveChangesAsync();

                return true;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<T> SelectAsync(string id)
        {
            try
            {
                return await _dataset.FindAsync(id);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<T>> SelectAsync()
        {
            try
            {
                return await _dataset.ToListAsync();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<T> UpdateAsync(T obj)
        {
            try
            {
                var result = await _dataset.SingleOrDefaultAsync(t => t.Id == obj.Id);

                if (result == null)
                    return null;

                obj.CreatedAt = result.CreatedAt;

                _context.Entry(result).CurrentValues.SetValues(obj);

                await _context.SaveChangesAsync();
                return obj;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> ExistAsync(string id)
        {
            try
            {
                return await _dataset.AnyAsync(t => t.Id == id);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
