﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using $safeprojectname$.Domain.Responses;

namespace $safeprojectname$.Resources.Responses.Base
{
    public class ErroResponse : IResponse
    {
        public bool Sucesso { get; set; }
        public string Mensagem { get; set; }

        public ErroResponse(string mensagem)
        {
            this.Mensagem = mensagem;
            Sucesso = false;
        }
    }
}
