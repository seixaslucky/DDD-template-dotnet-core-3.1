﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using $safeprojectname$.Domain.Responses;

namespace $safeprojectname$.Resources.Responses.Base
{
    public class BaseResponse<T> : IResponse
    {
        public bool Sucesso { get; set; }
        public string Mensagem { get; set; }
        public T Response { get; private set; }
        public IList<T> ResponseList { get; private set; }
        public IList<int> ResponseListInt { get; private set; }

        protected BaseResponse(T response = default, bool sucesso = true, string mensagem = "")
        {
            Mensagem = string.Empty;
            Response = response;
            Sucesso = sucesso;
        }

        protected BaseResponse(string mensagem, bool sucesso = true)
        {
            Response = default;
            Mensagem = mensagem;
            Sucesso = sucesso;
        }

        protected BaseResponse(IList<T> lista, string mensagem, bool sucesso = true)
        {
            ResponseList = lista;
            Mensagem = string.Empty;
            Sucesso = sucesso;
        }

        protected BaseResponse(IList<int> lista, string mensagem, bool sucesso = true)
        {
            ResponseListInt = lista;
            Mensagem = string.Empty;
            Sucesso = sucesso;
        }
    }
}
