﻿using AutoMapper;

namespace $safeprojectname$.CrossCutting.Mapping
{
    public class EntityToDto : Profile
    {
        public EntityToDto()
        {
        }
    }
}
