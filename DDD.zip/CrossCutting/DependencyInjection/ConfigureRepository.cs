﻿using Microsoft.Extensions.DependencyInjection;
using $safeprojectname$.Domain.Repositories;
using $safeprojectname$.Domain.Repositories.Base;
using $safeprojectname$.Infra.Repositories;
using $safeprojectname$.Infra.Repositories.Base;

namespace $safeprojectname$.CrossCutting.DependencyInjection
{
    public class ConfigureRepository
    {
        public static void ConfigureDependencyRepositories(IServiceCollection serviceCollection)
        {
            serviceCollection.AddScoped(typeof(IBaseRepository<>), typeof(BaseRepository<>));
        }
    }
}
