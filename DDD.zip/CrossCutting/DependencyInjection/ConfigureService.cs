﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.CrossCutting.DependencyInjection
{
    public class ConfigureService
    {
        public static void ConfigureDependencyService(IServiceCollection serviceCollection)
        {
        }
    }
}
