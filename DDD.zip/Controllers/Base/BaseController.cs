﻿using Microsoft.AspNetCore.Mvc;
using $safeprojectname$.Domain.Responses;

namespace $safeprojectname$.Controllers.Base
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseController : ControllerBase
    {
        protected const string _modeloInvalido = "Modelo fornecido inválido!";
        protected IActionResult MontaResposta(IResponse result)
        {
            if (result == null)
                return NoContent();

            if (!result.Sucesso)
                return BadRequest(result);

            return Ok(result);
        }
    }
}