using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using $safeprojectname$.CrossCutting.DependencyInjection;
using $safeprojectname$.CrossCutting.Mapping;
using $safeprojectname$.Infra.Context;

namespace $safeprojectname$
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            #region add context to database
            var userDb = Environment.GetEnvironmentVariable("DB_USERNAME");
            var passDb = Environment.GetEnvironmentVariable("DB_PASSWORD");
            var hostDb = Environment.GetEnvironmentVariable("DB_HOST");
            var portDb = Environment.GetEnvironmentVariable("DB_PORT");
            var serviceDb = Environment.GetEnvironmentVariable("DB_DATABASE");

            string connectionString = Configuration.GetConnectionString("DefaultConnection")
                .Replace("{USERNAME}", userDb)
                .Replace("{PASSWORD}", passDb)
                .Replace("{HOST}", hostDb)
                .Replace("{PORT}", portDb)
                .Replace("{DATABASE}", serviceDb);

            services.AddDbContext<MyContext>(
                   options => options.UseNpgsql(connectionString));
            #endregion

            #region dependency injetion
            ConfigureRepository.ConfigureDependencyRepositories(services);
            ConfigureService.ConfigureDependencyService(services);
            #endregion

            #region Authentication
            services
                   .AddAuthentication(options =>
                   {
                       options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                       options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                       options.DefaultSignInScheme = JwtBearerDefaults.AuthenticationScheme;
                   });
            #endregion

            #region automapper
            MapperConfiguration config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new EntityToDto());
            });
            IMapper mapper = config.CreateMapper();
            services.AddSingleton(mapper);
            #endregion

            #region swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name,
                    Version = "v1",

                });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Enter JWT Token.",
                    Name = "Authorization",
                    BearerFormat = "Bearer {token}",
                    Type = SecuritySchemeType.ApiKey
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                         new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Id = "Bearer",
                            Type = ReferenceType.SecurityScheme
                        }
                    }, new List<string>()
                    }
                });
            });
            #endregion

            services.AddHealthChecks();

            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
                c.RoutePrefix = string.Empty;
            });

            app.UseHealthChecks("/health");

            app.UseAuthentication();

            app.UseHttpsRedirection();

            app.UseRouting();

            //app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
